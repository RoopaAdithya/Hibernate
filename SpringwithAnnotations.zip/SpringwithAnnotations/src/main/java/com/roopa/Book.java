package com.roopa;

public interface Book {

	void getBookInfo();
}
