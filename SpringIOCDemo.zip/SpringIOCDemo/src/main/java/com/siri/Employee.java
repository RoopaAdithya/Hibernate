package com.siri;
public interface Employee {
	
	void calculateSalary();

}
