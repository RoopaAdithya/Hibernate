package com.siri;

public class RegularEmployee implements Employee {

	public void calculateSalary() {


		System.out.println("Calculating RegularEmployee salary");
		
	}

}
