package com.siri;

public class ContractEmployee implements Employee {

	public void calculateSalary() {

		System.out.println("Calculating Contract Employee Salary");

	}

}
