package com.dao;

import java.util.ArrayList;

import com.beans.BankBean;

public interface Bank {

	
	void addBank();
	ArrayList<BankBean> viewAllBanks();
}
