package com.daoimpl;

import java.util.ArrayList;

import com.beans.BankBean;
import com.dao.Bank;

public class BankImpl implements Bank {

	@Override
	public void addBank() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<BankBean> viewAllBanks() {
		// TODO Auto-generated method stub
		return null;
	}

}
