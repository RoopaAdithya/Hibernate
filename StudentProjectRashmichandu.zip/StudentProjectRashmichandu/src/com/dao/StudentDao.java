package com.dao;

public interface StudentDao {

	void addStudent();
	void viewAllStudents();
	void viewParticularStudent();
}
