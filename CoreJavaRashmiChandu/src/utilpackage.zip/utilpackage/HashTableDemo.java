package utilpackage;

import java.util.Hashtable;

public class HashTableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hashtable  h=new Hashtable<>();
		h.put(1, "Raju");
		h.put(100,"Kiran");
		h.put("two","Jai");
		h.put(null,"Pooja");
		System.out.println(h);

	}

}


