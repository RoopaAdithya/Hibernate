package com.daoimpl;

import com.dao.Employee;

/**
 * @author pc
 * EmployeeImplenetaionn
 *
 */
public class EmployeeImpl implements Employee {

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub

	}

}
