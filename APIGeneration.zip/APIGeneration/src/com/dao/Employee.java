package com.dao;

/**
 * @author pc
 * EmployeeInterface
 *
 */
public interface Employee {

	void getInfo();
}
