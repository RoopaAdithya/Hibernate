package foo;

import javax.persistence.Entity;

@Entity
public class Student2 {

	
}
