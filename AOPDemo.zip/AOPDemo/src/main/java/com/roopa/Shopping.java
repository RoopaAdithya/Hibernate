package com.roopa;

import org.springframework.stereotype.Component;

@Component
public class Shopping {

	
	public void addtoCart()
	{
		
		System.out.println("Add to cart");
	}
}
